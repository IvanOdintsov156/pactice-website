from django.db import models
from pract_sheet.models import DIRECTION


class notification(models.Model):
    id = models.AutoField(primary_key=True)
    full_name = models.CharField("ФИО", max_length=500, default='')
    post = models.CharField("Должность", max_length=250, default='')
    email = models.EmailField("Почта")
    direction = models.ManyToManyField(DIRECTION, verbose_name="Направление практики")

    def __str__(self):
        return self.email

    class Meta:
        verbose_name = "Рассылка"
        verbose_name_plural = "Рассылки"
