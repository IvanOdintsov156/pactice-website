from django.conf import settings
from notification.models import notification
from pract_sheet.models import DIRECTION, PRACTICE
from django.contrib.auth.models import User
from django.core.mail import send_mass_mail

def send_mails_for_represent(direction):
    a = notification.objects.filter(direction=direction)
    users = (("Письмо", f"Здравствуйте, {i.full_name}, была создана новая практика", settings.EMAIL_HOST_USER, [i.email]) for i in a)
    send_mass_mail(users, fail_silently=False)

def send_mails_for_admin(id):
    a = User.objects.filter(is_superuser=True)
    b = PRACTICE.objects.get(practice_id=id)
    users = (("Письмо", f"Здравствуйте, была создана новая практика {b.practice_name}.", settings.EMAIL_HOST_USER, [i.email]) for i in a)
    send_mass_mail(users, fail_silently=False)

