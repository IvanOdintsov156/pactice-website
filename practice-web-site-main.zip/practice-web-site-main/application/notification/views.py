from django.shortcuts import render, redirect
from django.urls import reverse
from .forms import Add_Notification
from .models import notification
from django.conf import settings
from django.core.mail import send_mail
from django.http import Http404, HttpResponseRedirect


def index(request):
    if request.method == 'GET':
        form = Add_Notification()
        return render(request, 'notification/index.html', {'form': form})
    if request.method == 'POST':
        form = Add_Notification(request.POST)
        if form.is_valid():
            full_name = form.cleaned_data['full_name']
            post = form.cleaned_data['post']
            email = form.cleaned_data['email']
            if notification.objects.filter(email=email):
                notification.objects.filter(email=email).delete()
                instance = notification.objects.create(full_name=full_name,
                                                       post=post,
                                                       email=email
                                                       )
                instance.direction.set(form.cleaned_data['direction'])
            else:
                instance = notification.objects.create(full_name=full_name,
                                                       post=post,
                                                       email=email
                                                       )
                instance.direction.set(form.cleaned_data['direction'])

            send_mail("Письмо",f"Здравствуйте, {full_name}, вам на почту будут приходить сообщения о создании практик.",settings.EMAIL_HOST_USER, [email])
            return HttpResponseRedirect(reverse('notification:index'))
        else:
            return render(request, 'representatives/register.html', {'form': form})
