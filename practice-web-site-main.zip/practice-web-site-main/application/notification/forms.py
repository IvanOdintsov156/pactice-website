from django import forms
from .models import notification

class Add_Notification(forms.ModelForm):
    class Meta:
        model = notification
        fields = ['full_name', 'post', 'email', 'direction']
        widgets = {
            'direction': forms.CheckboxSelectMultiple(attrs={'class': 'form-input'})
        }