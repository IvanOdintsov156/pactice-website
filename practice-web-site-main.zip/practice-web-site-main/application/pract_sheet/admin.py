from django.contrib import admin

from .models import PRACTICE, REGION, DIRECTION, STUDENT_RESPONSE

admin.site.register(PRACTICE)
admin.site.register(REGION)
admin.site.register(DIRECTION)
admin.site.register(STUDENT_RESPONSE)
