from django.apps import AppConfig


class PractSheetConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pract_sheet'
