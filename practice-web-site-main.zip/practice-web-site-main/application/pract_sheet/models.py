import datetime
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.contrib.postgres.fields import ArrayField

class REGION(models.Model):
    region_id = models.AutoField(primary_key=True)
    region_name = models.CharField("Регион присутствия",max_length=500)

    def __str__(self):
        return self.region_name

    class Meta:
        verbose_name = "Регион присутствия"
        verbose_name_plural = "Регионы присутствия"


class DIRECTION(models.Model):
    direction_id = models.AutoField(primary_key=True)
    direction_name = models.CharField("Направление практики",max_length=500)

    def __str__(self):
        return self.direction_name

    class Meta:
        verbose_name = "Направление практики"
        verbose_name_plural = "Направления практик"



class PRACTICE(models.Model):
    practice_id = models.AutoField(primary_key=True)
    user_id = models.ForeignKey(User, blank=True, null=True, on_delete=models.CASCADE,name="Создатель объявления")
    practice_name = models.CharField("Название практики", max_length=200)
    practice_direction = models.ForeignKey(DIRECTION, blank=True, null=True, on_delete=models.CASCADE,name="Направление практики")
    task_description = models.TextField("Описание задачи")
    practice_location = models.ManyToManyField(REGION, blank=True, name="Регион присутствия")
    professional_skills = models.CharField("Требуемые навыки", max_length=500)
    practice_start = models.DateTimeField("Начало прохождения практики")
    practice_end = models.DateTimeField("Конец прохождения практики")
    practice_paid = models.BooleanField("Назначение оплаты")
    practice_validity = models.IntegerField("Срок действия")

    def __str__(self):
        return self.practice_name

    def published_recently(self):
        return self.practice_start >= (timezone.now() - datetime.timedelta(days=7))

    class Meta:
        verbose_name = "Практика"
        verbose_name_plural = "Практики"


class STUDENT_RESPONSE(models.Model):
    response_id = models.AutoField(primary_key=True)
    practice = models.ForeignKey(PRACTICE, blank=True, null=True, on_delete=models.CASCADE,name="ID практики")
    first_name = models.CharField("Имя", max_length=150)
    last_name = models.CharField("Фамилия", max_length=150)
    father = models.CharField("Отчество", max_length=150)
    e_mail = models.EmailField("Почта")
    telephone_number = models.CharField("Номер телефона", max_length=30)

    def __str__(self):
        return self.first_name

    class Meta:
        verbose_name = "Заявка студента"
        verbose_name_plural = "Заявки студентов"