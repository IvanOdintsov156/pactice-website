from django.http import Http404, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import PRACTICE, DIRECTION
from .forms import ADD_form
from notification.script import *
from django.contrib.auth.models import User

def index(request):
    latest_pract_list = PRACTICE.objects.order_by('-practice_start')[:5]
    #send_mails_for_represent(DIRECTION.objects.get(direction_id=4))
    #send_mails_for_admin(1)
    return render(request, 'pract_sheet/admin/list.html',{'latest_pract_list':latest_pract_list})

def detail(request,practice_id):
    try:
        a = PRACTICE.objects.get(practice_id=practice_id)
    except:
        raise Http404("Статья не найдена")

    return render(request, 'pract_sheet/admin/detail.html', {'practice':a})

def leave_response(request,practice_id):
    try:
        a = PRACTICE.objects.get(practice_id=practice_id)
    except:
        raise Http404("Статья не найдена")
    a.student_response_set.create(first_name = request.POST['first_name'],last_name = request.POST['last_name'],father = request.POST['father'],e_mail = request.POST['e_mail'],telephone_number = request.POST['telephone_number'])
    return HttpResponseRedirect(reverse('pract_sheet:detail',args=(a.practice_id,)))
def add_page(request):
    form = ADD_form()
    return render(request,'pract_sheet/admin/add.html',{'form': form})
def add_practice(request):
    if request.method == 'GET':
        form = ADD_form()
        return render(request, 'pract_sheet/admin/add.html', {'form': form})
    if request.method == 'POST':
        form = ADD_form(request.POST)
        if form.is_valid():
            a = PRACTICE(practice_name = form.cleaned_data["practice_name"],
                         practice_direction = form.cleaned_data["practice_direction"],
                         task_description = form.cleaned_data["task_description"],
                         practice_location = form.cleaned_data["practice_location"],
                         professional_skills = form.cleaned_data["professional_skills"],
                         practice_start = form.cleaned_data["practice_start"],
                         practice_end = form.cleaned_data["practice_end"],
                         practice_paid =form.cleaned_data("practice_paid",False),
                         practice_validity = form.cleaned_data["practice_validity"]
                         )
            a.save()
            return redirect('pract_sheet:index')
        else:
            return render(request, 'pract_sheet/admin/add.html',{'form': form})
