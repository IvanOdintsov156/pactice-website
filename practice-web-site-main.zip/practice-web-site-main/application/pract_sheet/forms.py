from django import forms
from .models import PRACTICE, REGION, DIRECTION


class ADD_form(forms.ModelForm):

    '''region = forms.ModelChoiceField(queryset=REGION.objects.all(),
        help_text='Место прибывания', label='test'
    )
    direction = forms.ModelChoiceField(queryset=DIRECTION.objects.all(),
        help_text='Направление практики', label='test'
    )'''

    class Meta:
        model = PRACTICE
        #fields = ['practice_name','practice_direction','task_description','practice_location','professional_skills','practice_start','practice_end','practice_paid','practice_validity']
        fields = '__all__'
        widgets = {
            'practice_start': forms.DateTimeInput(attrs={'class': 'form-control datetimepicker-input','data-target': '#datetimepicker1'}),
            'practice_end': forms.DateTimeInput(attrs={'class': 'form-control datetimepicker-input','data-target': '#datetimepicker1'}),}

