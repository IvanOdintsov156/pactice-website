from django.urls import path

from . import views

app_name = 'pract_sheet'
urlpatterns = [
    path("", views.index, name="index"),
    path("<int:practice_id>/", views.detail, name="detail"),
    path("add_practice/", views.add_practice, name="add_practice"),
    path("add_page/", views.add_page, name="add_page"),
    path("<int:practice_id>/leave_response/", views.leave_response, name="leave_response"),
]