from django.db import models

class students():
    pass