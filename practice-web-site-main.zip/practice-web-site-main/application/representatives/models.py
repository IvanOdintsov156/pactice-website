from django.db import models
from django.contrib.auth.models import User

'''class representatives_auth(models.Model):
    representative_id = models.AutoField(primary_key=True)
    email = models.EmailField("Почта")
    password = models.CharField("Пароль", max_length=50)'''

class position(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField("Название",max_length=250)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Регион присутствия"
        verbose_name_plural = "Регионы присутствия"

class speciality(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField("Название",max_length=250)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Специальность"
        verbose_name_plural = "Специальности"

class representatives_staff(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField("Имя", max_length=150)
    second_name = models.CharField("Фамилия", max_length=150)
    middle_name = models.CharField("Отчество", max_length=150)
    #position = models.CharField("Регион прибывания", max_length=150, default=" ")
    position = models.ForeignKey(position, on_delete=models.CASCADE)
    phone_number = models.CharField("Номер телефона", max_length=17)
    email = models.EmailField("Почта")
    #speciality = models.CharField("Специальность", max_length=150, default=" ")
    speciality = models.ForeignKey(speciality, on_delete=models.CASCADE)

    def __str__(self):
        return self.email

    class Meta:
        verbose_name = "Представитель СУЗ/ВУЗ"
        verbose_name_plural = "Представители СУЗ/ВУЗ"