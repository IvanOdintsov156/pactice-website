from django.urls import path, include
from . import views

app_name = 'representatives'
urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.sign_up, name='register'),
    path('<int:user_id>/', views.sign_up1, name='register1'),
    path('log_out/', views.log_out, name='log_out'),
    path('log_in/', views.log_in, name='log_in'),
]