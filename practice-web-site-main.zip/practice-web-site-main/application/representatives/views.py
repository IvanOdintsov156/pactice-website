from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth import login, authenticate, logout
from .forms import LoginForm, RegisterForm, ModeratorForm
from .models import representatives_staff
from django.http import Http404, HttpResponseRedirect
from django.contrib.auth.models import Group, User


def index(request):
    return render(request, 'representatives/index.html')


def sign_up(request):
    if request.method == 'GET':
        form = RegisterForm()
        return render(request, 'representatives/register.html', {'form': form})

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.username = user.email
            user.save()
            messages.success(request, 'You have singed up successfully.')
            #login(request, user)
            user_group = Group.objects.get(name="Moderator")
            user.groups.add(user_group)
            return redirect('representatives:register1', user.id)
        else:
            return render(request, 'representatives/register.html', {'form': form})


def sign_up1(request, user_id):
    if request.method == 'GET':
        form = ModeratorForm()
        return render(request, 'representatives/register.html', {'form': form})

    if request.method == 'POST':
        form = ModeratorForm(request.POST)
        if form.is_valid():
            user = User.objects.get(id=user_id)
            a = representatives_staff(user=user,
                                      first_name=form.cleaned_data['first_name'],
                                      second_name=form.cleaned_data['second_name'],
                                      middle_name=form.cleaned_data['middle_name'],
                                      position=form.cleaned_data['position'],
                                      phone_number=form.cleaned_data['phone_number'],
                                      email=user.email,
                                      speciality=form.cleaned_data['speciality']
                                      )
            a.save()
            return redirect('representatives:index')
        else:
            return render(request, 'representatives/register.html', {'form': form})

def log_out(request):
    logout(request)
    return redirect('representatives:index')


def log_in(request):
    if request.method == 'GET':
        form = LoginForm()
        return render(request, 'representatives/login.html', {'form': form})

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(username=request.POST['email'], password=request.POST['password'])
            if user is not None:
                login(request, user)
                return redirect('representatives:index')
            else:
                return HttpResponseRedirect(reverse('representatives:log_in'))


