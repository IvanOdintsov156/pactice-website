from django.contrib import admin
from .models import position, speciality, representatives_staff

admin.site.register(position)
admin.site.register(speciality)
admin.site.register(representatives_staff)
