from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import PracticeCreateForm,ModeratorProfileForm
from .models import Moderator,Practice
from django.core.paginator import Paginator

def moderator_profile(request, moderator_id):
    moderator = Moderator.objects.get(id=moderator_id)
    return render(request, 'moderators/.html', {'moderator': moderator})
def moderator_dashboard(request):
    # Remove the line that fetches the ModeratorLogin object

    if request.method == 'POST':
        form = ModeratorProfileForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Форма успешно сохранена.')
            return redirect('moderator_dashboard')
    else:
        form = ModeratorProfileForm()

    return render(request, 'moderators/moderator_dashboard.html', {'form': form})

def create_practice(request):
    if request.method == 'POST':
        form = PracticeCreateForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('practice_list')
    else:
        form = PracticeCreateForm()
    return render(request, 'moderators/practice_create_form.html', {'form': form})



def practice_list(request):
    practices = Practice.objects.all()
    paginator = Paginator(practices, 10)  # Разделение на страницы, по 10 практик на страницу
    page = request.GET.get('page')  # Получение номера текущей страницы из GET-параметра

    practices = paginator.get_page(page)

    return render(request, 'moderators/base.html', {'practices': practices})