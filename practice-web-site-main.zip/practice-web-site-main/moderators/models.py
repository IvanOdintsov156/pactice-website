from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils.translation import gettext_lazy as _

from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import Group, Permission
class Moderator(AbstractUser):
    position = models.CharField(max_length=255)
    department = models.CharField(max_length=255)
    phone = models.CharField(max_length=255)
    region = models.CharField(max_length=255)
    groups = models.ManyToManyField(
        Group,
        verbose_name=_('группа'),
        blank=True,
        help_text=_(
            'Группа, к которой будет относиться пользователь.'
        ),
        related_name='moderators_set' # Add a related_name argument to avoid clash
    )

    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name=_('разрешение'),
        blank=True,
        help_text=_('Специальные разрешения, которые будут предоставлены этому пользователю.'),
        related_name='moderators_set' # Add a related_name argument to avoid clash
    )

    def __str__(self):
        return f'{self.get_full_name()} - {self.position}'

    class Meta:
        verbose_name = 'Модератор'
        verbose_name_plural = 'Модераторы'
 
class Practice(models.Model):
    REGIONS = [
        ('Москва и Московская область', _('Москва и Московская область')),
        ('Санкт-Петербург и Ленинградская область', _('Санкт-Петербург и Ленинградская область')),
        ('Владимир и Владимирская область', _('Владимир и Владимирская область')),
        ('Екатеринбург и Свердловская область', _('Екатеринбург и Свердловская область')),
        ('Новосибирск и Нижегородская область', _('Новосибирск и Нижегородская область')),
        ('Казань и Республика Татарстан', _('Казань и Республика Татарстан')),
        ('Челябинск и Челябинская область', _('Челябинск и Челябинская область')),
        ('Омск и Омская область', _('Омск и Омская область')),
        ('Самара и Самарская область', _('Самара и Самарская область')),
        ('Ростов-на-Дону и Ростовская область', _('Ростов-на-Дону и Ростовская область')),
        ('Уфа и Республика Башкортостан', _('Уфа и Республика Башкортостан')),
        ('Краснодар и Краснодарский край', _('Краснодар и Краснодарский край')),
        ('Волгоград и Волгоградская область', _('Волгоград и Волгоградская область')),
        ('Саратов и Саратовская область', _('Саратов и Саратовская область')),
        ('Красноярск и Красноярский край', _('Красноярск и Красноярский край')),
        ('Пермь и Пермская область', _('Пермь и Пермская область')),
        ('Воронеж и Воронежская область', _('Воронеж и Воронежская область')),
        ('Тюмень и Тюменская область', _('Тюмень и Тюменская область')),
        ('Архангельск и Архангельская область', _('Архангельск и Архангельская область')),
        ('Нижний Новгород и Нижегородская область', _('Нижний Новгород и Нижегородская область')),
        ('Ульяновск и Ульяновская область', _('Ульяновск и Ульяновская область')),
        ('Оренбург и Оренбургская область', _('Оренбург и Оренбургская область')),
        ('Томск и Томская область', _('Томск и Томская область')),
        ('Ярославль и Ярославская область', _('Ярославль и Ярославская область')),
    ]
    DIRECTION_CHOICES  = [
        ("экономическое", "ЭКОНОМИЧЕСКОЕ"),
        ("техническое", "ТЕХНИЧЕСКОЕ"),
    ]

    practice_director_full_name = models.CharField(max_length=255, verbose_name='ФИО руководителя практики')
    name_of_PSK_or_structure = models.CharField(max_length=255, verbose_name='Название ПСК или структуры')
    need_amount_of_practicants = models.IntegerField(verbose_name='Требуемое количество практикантов')
    practice_description = models.TextField(verbose_name='Описание практики')
    required_skills = models.TextField(verbose_name='Требуемые навыки/квалификации')
    start_date = models.DateField(verbose_name='Дата начала')
    end_date = models.DateField(verbose_name='Дата окончания')
    direction = models.CharField(verbose_name='Направление практики', max_length=255, choices=DIRECTION_CHOICES )
    create_date = models.DateTimeField(verbose_name='Дата создания', auto_now_add=True)
    region = models.CharField(max_length=255, choices=REGIONS, verbose_name='Регион')
    def __str__(self):
        return self.name_of_PSK_or_structure
    
    class Meta:
        verbose_name = _('Создание практики')
        verbose_name_plural = _('Создание практики')