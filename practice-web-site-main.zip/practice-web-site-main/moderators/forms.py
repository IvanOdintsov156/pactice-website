from django import forms
from .models import Moderator, Practice
REGIONS=Practice().REGIONS
class ModeratorProfileForm(forms.ModelForm):
    class Meta:
        model = Moderator
        fields = ['username', 'password', 'position', 'department', 'phone', 'region']
        labels = {
            'username': 'Имя пользователя',
            'password': 'Пароль',
            'position': 'Должность',
            'department': 'Отдел',
            'phone': 'Телефон',
            'region': 'Регион',
        }

class PracticeCreateForm(forms.ModelForm):
    REGIONS = REGIONS
    class Meta:
        model = Practice
        fields = ['name_of_PSK_or_structure', 'region', 'practice_director_full_name', 'need_amount_of_practicants', 'practice_description', 'required_skills', 'start_date', 'end_date', 'direction']
        widgets = {
        'name_of_PSK_or_structure': forms.TextInput(attrs={'class': 'custom-input'}),
        'start_date': forms.DateInput(attrs={'type': 'date'}),
        'end_date': forms.DateInput(attrs={'type': 'date'}),
        'region': forms.Select(choices=REGIONS),
        'direction': forms.Select(choices=Practice.DIRECTION_CHOICES),
    }
        error_messages = {
            'name_of_PSK_or_structure': {
                'required': 'Поле "Название ПСК или структуры" обязательно для заполнения',
            },
            'region': {
                'required': 'Поле "Регион" обязательно для заполнения',
            },
            'practice_director_full_name': {
                'required': 'Поле "ФИО руководителя практики" обязательно для заполнения',
            },
            'need_amount_of_practicants': {
                'required': 'Поле "Требуемое количество практикантов" обязательно для заполнения',
            },
            'practice_description': {
                'required': 'Поле "Описание практики" обязательно для заполнения',
            },
            'required_skills': {
                'required': 'Поле "Требуемые навыки/квалификации" обязательно для заполнения',
            },
            'start_date': {
                'required': 'Поле "Дата начала" обязательно для заполнения',
            },
            'end_date': {
                'required': 'Поле "Дата окончания" обязательно для заполнения',
        }}