from django.urls import path
from .views import (
    moderator_dashboard,
    create_practice,
    practice_list,
    moderator_profile
)

app_name = 'moderators'

urlpatterns = [
    path('dashboard/', moderator_dashboard, name='moderator_dashboard'),
    path('practice_create_form/', create_practice, name='practice_create_form'),
    path('practices/', practice_list, name='practice_list'),
     path('moderator/<int:moderator_id>/', moderator_profile, name='moderator_profile'),
    
]