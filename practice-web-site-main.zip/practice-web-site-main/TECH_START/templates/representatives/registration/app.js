const App = {
    data() {
        return {
            loginValue: "",
            mailValue: "",
            passValue: "",
            passConfValue: "",

            logWarn: "",
            mailWarn: "",
            passWarn: "",
            passConfWarn: "",
        }
    },
    methods: {
        formSubmit() {

            // Задаем значения для обнуления ошибок при их исправлении пользователем
            this.logWarn = ""
            this.mailWarn = ""
            this.passWarn = ""
            this.passConfWarn = ""
            // Задаем значения для обнуления ошибок при их исправлении пользователем

            // Счетчик правильных проверок (ошибка = -1)
            let comleted = 8

            if (this.loginValue.length <= 3) {
                this.logWarn = "Ваш логин слишком мал"
                comleted -= 1
            }
            if (this.passValue === this.loginValue) {
                this.logWarn = "Нельзя создавать идентичные логин и пароль"
                comleted -= 1
            }
            if (!(this.mailValue.includes("@"))) {
                this.mailWarn = "Неподходящий формат почты"
                comleted -= 1
            }

            if (this.passValue.length != 0) {
                if (this.passValue[0] !== this.passValue[0].toUpperCase()) {
                    this.passWarn = "Пароль должен начинаться с заглавной буквы"
                    comleted -= 1
                }
            } else {
                comleted -= 1
            }

            if (this.passValue.length < 8) {
                this.passWarn = "Пароль должен содержать минимум 8 символов"
                comleted -= 1
            }
            if ((this.passValue.includes(" "))) {
                this.passWarn = "В пароле не может быть пробелов"
                comleted -= 1
            }
            if (((this.passValue.match(/\d/g) || []).length) < 4) {
                this.passWarn = "Пароль должен содержать минимум 4 цифры"
                comleted -= 1
            }
            if (this.passValue !== this.passConfValue) {
                this.passConfWarn = "Пароли не совпадают"
                comleted -= 1
            }

            // Проверка на правильность пароля 8 из 8 = успех
            if (comleted === 8) {

                //.......Код для отправки данных на сервер
                //.......Код для отправки данных на сервер
                //.......Код для отправки данных на сервер




                //Обнуление полей
                this.loginValue = "",
                this.mailValue = "",
                this.passValue = "",
                this.passConfValue = ""
                //Обнуление полей
            }

        },
    }
}

Vue.createApp(App).mount("#app")